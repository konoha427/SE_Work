/**************************************************************************************************/
/* Copyright (C) mc2lab.com, SSE@USTC, 2014-2015                                                  */
/*                                                                                                */
/*  FILE NAME             :  menu.c                                                               */
/*  PRINCIPAL AUTHOR      :  Shi Weihao JG14225071                                                */
/*  SUBSYSTEM NAME        :  menu                                                                 */
/*  MODULE NAME           :  menu                                                                 */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/20                                                           */
/*  DESCRIPTION           :  This is a menu program                                               */
/**************************************************************************************************/

/*
* Revision log:
*
* Created by Shi Weihao JG14225071, 2014/09/20
*
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "menu.h"

/*initialize globle variable*/

tLinkTable * pLinkHead = NULL;

/*find the command given*/
tDataNode * FindCmd(tLinkTable * lhead, char * cmd)
{
	return NULL;
}

/*show all the command*/
int ShowAllCmd(tLinkTable * lhead)
{
	if (lhead == NULL)
	{
		return FAILURE;
	}
	return SUCCESS;
}

int Help()
{
	return 0;
}

/*create the menu list*/
int CreateMenu(tDataNode * data)
{
	if (data == NULL)
	{
		return FAILURE;
	}
	return SUCCESS;
}

/*add the command given to the menu list*/
int AddCmd()
{
	return 0;
}

/*delete the command given from the list*/
int DelCmd()
{
	return 0;
}

/*run the menu list*/
int RunMenu()
{
	return 0;
}
