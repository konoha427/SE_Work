#include<stdio.h>
#include"menu.h"

#define debug printf

int results[8] = { 1, 1, 1, 1, 1, 1, 1, 1 };
char * info[8] =
{
    "test report",
    "TC1 CreateLinkTable",
    "TC2 ShowAllCmd",
    "TC3 FindCmd",
    "TC4 RunMenu",
    "TC5 AddCmd",
    "TC6 DelCmd",
    "TC7 Help"
};

int main()
{
	/*function CreateMenu*/
	int i;
	tDataNode * data = NULL;
	int iCreate = CreateMenu(data);
	if (iCreate == 0)
	{
		debug("TC1 fail\n");
		results[1] = 1;
	}

	/*function ShowAllCmd*/
	tLinkTable * head = NULL;
	int iShow = ShowAllCmd(head);
	if (iShow == FAILURE)
	{
		debug("TC2.1 Succ\n");
		results[2] = 1;
	}

	/*function FindCmd*/
	char * cmd = NULL;
	tDataNode * pNode = FindCmd(head, cmd);
	if (pNode == NULL)
	{
		debug("TC3.1 Succ\n");
		results[3] = 1;
	}

	/*function RunMenu*/
	int iRun = RunMenu();
	if (iRun == 0)
	{
		debug("TC4.1 Succ\n");
		results[4] = 1;
	}

	/*function AddCmd*/
	int iAdd = AddCmd();
	if (iAdd == 0)
	{
		debug("TC5.1 Succ\n");
		results[5] = 1;
	}

	/*function DelCmd*/
	int iDel = DelCmd();
	if (iDel == 0)
	{
		debug("TC6.1 Succ\n");
		results[6] = 1;
	}

	/*function Help*/
	int iHelp = Help();
	if (iHelp == 0)
	{
		debug("TC7.1 Succ\n");
		results[7] = 1;
	}
	/* more test case ...*/

	/* test report */
	printf("test report\n");
	for (i = 1; i <= 7; i++)
	{
		if (results[i] == 1)
		{
			printf("Testcase Number%d F - %s\n", i, info[i]);
		}
	}
	return 0;
}
